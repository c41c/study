function name_p_n_12() {
  document.querySelectorAll(".content_section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("class12_physics_chap").classList.add("active");
  setActiveIcon("class12_physics_chap");
}
function name_c_n_12() {
  document.querySelectorAll(".content_section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("class12_chemistry_chap").classList.add("active");
  setActiveIcon("class12_chemistry_chap");
}
function name_b_n_12() {
  document.querySelectorAll(".content_section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("class12_biology_chap").classList.add("active");
  setActiveIcon("class12_biology_chap");
}
function name_m_n_12() {
  document.querySelectorAll(".content_section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("class12_maths_chap").classList.add("active");
  setActiveIcon("class12_maths_chap");
}
function name_p_fs_12() {
  document.querySelectorAll(".content_section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("class12_physics_formulaSheet_chap").classList.add("active");
  setActiveIcon("class12_physics_formulaSheet_chap");
}
function name_c_fs_12() {
  document.querySelectorAll(".content_section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("class12_chemistry_formulaSheet_chap").classList.add("active");
  setActiveIcon("class12_chemistry_formulaSheet_chap");
}
function name_m_fs_12() {
  document.querySelectorAll(".content_section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("class12_maths_formulaSheet_chap").classList.add("active");
  setActiveIcon("class12_maths_formulaSheet_chap");
}